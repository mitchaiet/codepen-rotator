# CSS Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/nilsynils/pen/EZzyVB](https://codepen.io/nilsynils/pen/EZzyVB).

